WITH TicketReportCounts AS (
    SELECT 
        ur.ticket_id,
        COUNT(*) AS report_count,
        ROW_NUMBER() OVER (ORDER BY COUNT(*) DESC) AS rn
    FROM 
        user_reports ur
    GROUP BY 
        ur.ticket_id
),
TopTicket AS (
    SELECT ticket_id
    FROM TicketReportCounts
    WHERE rn = 1
)
SELECT 
    r.subject,
    COUNT(*) AS report_count
FROM 
    user_reports ur
JOIN 
    reports r ON ur.report_id = r.id
JOIN 
    TopTicket tt ON ur.ticket_id = tt.ticket_id
GROUP BY 
    r.subject;
