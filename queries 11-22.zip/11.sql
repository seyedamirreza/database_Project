SELECT
    firstName,
    lastName
FROM
    users
WHERE
    role_id = 1;