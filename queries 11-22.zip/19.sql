DELETE tr
FROM ticket_reserve tr
JOIN users u ON tr.user_id = u.id
WHERE 
    tr.status = 'canceled' AND      --! is really 'canceled' in tables?
    u.lastName = 'Redington';