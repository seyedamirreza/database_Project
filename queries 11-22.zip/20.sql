DELETE FROM ticket_reserve
WHERE status = 'canceled';      --! is really 'canceled' in tables?